//#pragma once

#include <G4SystemOfUnits.hh>
#include <G4UserEventAction.hh>
#include "G4Event.hh"
#include <fstream>
#include "SD_Si_det_hit.hh"
#include <iomanip>

class EventAct : public G4UserEventAction 
{
 public:
        std::ofstream *f_event;

	EventAct(std::ofstream&);
	~EventAct();

        static void Coordinates(G4ThreeVector V1, G4ThreeVector V2);
        static void AddE(G4double dE);
        static void StepLengthCounter(G4double SL); //������� ������ �������� (�� �����)

	void BeginOfEventAction(const G4Event*);
	void EndOfEventAction(const G4Event*);
};
